# EmulatorJS Core: <!-- EJS_CORE_NAME -->

This package contains the stable EmulatorJS core: <!-- EJS_CORE_NAME -->

Lean more about EmulatorJS at https://emulatorjs.org

Core repository:
<!-- EJS_CORE_REPO -->

Core is build using this repository:
https://github.com/EmulatorJS/build

## How to install

To install core, run the following command:

```bash
npm install @emulatorjs/core-<!-- EJS_CORE_NAME -->
```
To install all cores, run the following command:

```bash
npm install @emulatorjs/cores
```

